import { useEffect, useRef, useState, type FormEvent } from 'react'
import services from '../data/services'
import { budgets, enquiryForm, site } from '../data/site'

type Submission = { status: 'idle' | 'pending' | 'error' | 'success' }

export function EnquiryForm({
  serviceId,
  onServiceChange,
}: {
  serviceId: string
  onServiceChange: (id: string) => void
}) {
  const [submission, setSubmission] = useState<Submission>({ status: 'idle' })
  const submitting = useRef(false)
  const service = services.find((item) => item.id === serviceId)

  useEffect(() => {
    if (!submitting.current) setSubmission({ status: 'idle' })
  }, [serviceId])

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (submitting.current || submission.status === 'success') return
    const body = new URLSearchParams()
    new FormData(event.currentTarget).forEach((value, key) =>
      body.append(key, String(value)),
    )
    submitting.current = true
    setSubmission({ status: 'pending' })
    try {
      const response = await fetch(enquiryForm.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
        signal: AbortSignal.timeout(15000),
      })
      // A plain preview may echo the static registration page with HTTP 200.
      if (!response.ok || /\bdata-netlify\s*=/i.test(await response.text()))
        throw new Error('Enquiry was not accepted')
      setSubmission({ status: 'success' })
    } catch {
      setSubmission({ status: 'error' })
    } finally {
      submitting.current = false
    }
  }

  return (
    <section
      id="contact"
      tabIndex={-1}
      aria-labelledby="contact-heading"
      className="scroll-mt-20 bg-paper-deep"
    >
      <div className="mx-auto grid max-w-7xl gap-14 px-5 py-24 sm:px-8 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <p className="eyebrow mb-6 text-ember">Start a project</p>
          <h2 id="contact-heading" className="display text-6xl sm:text-7xl">
            Tell us where you want to <em>grow.</em>
          </h2>
          <p id="contact-note" className="mt-6 max-w-md text-lg text-ink-soft">
            Share a few details and a strategist will reply within one business
            day with next steps — usually a free 30-minute growth call.
          </p>
          <ul className="mt-10 space-y-3 text-ink-soft">
            {[
              'No-obligation audit of your current channels',
              'Honest advice, even if we’re not the right fit',
              'Clear proposal with scope, timeline, and pricing',
            ].map((item) => (
              <li key={item} className="flex gap-3">
                <span
                  aria-hidden
                  className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-ember"
                />
                {item}
              </li>
            ))}
          </ul>
          <p className="mt-10 text-sm text-ink-soft">
            Prefer email?{' '}
            <a href={`mailto:${site.email}`} className="action-ghost">
              {site.email}
            </a>
          </p>
        </div>

        {submission.status === 'success' ? (
          <div
            role="status"
            className="flex flex-col items-start justify-center rounded-3xl bg-ink p-10 text-paper sm:p-14"
          >
            <span
              aria-hidden
              className="mb-8 grid h-14 w-14 place-items-center rounded-full bg-ember text-2xl"
            >
              ✓
            </span>
            <p className="display text-5xl">Thanks — we’re on it.</p>
            <p className="mt-4 max-w-sm text-paper/70">
              Your enquiry{service ? ` about ${service.name}` : ''} landed in
              our inbox. Expect a reply within one business day.
            </p>
            <button
              type="button"
              className="mt-8 font-semibold underline decoration-ember decoration-2 underline-offset-[6px]"
              onClick={() => setSubmission({ status: 'idle' })}
            >
              Send another enquiry
            </button>
          </div>
        ) : (
          <form
            name={enquiryForm.name}
            method="POST"
            action={enquiryForm.endpoint}
            data-netlify="true"
            netlify-honeypot="bot-field"
            onSubmit={submit}
            aria-busy={submission.status === 'pending'}
            onChange={() => {
              if (!submitting.current && submission.status === 'error')
                setSubmission({ status: 'idle' })
            }}
            className="rounded-3xl bg-paper p-7 shadow-[0_30px_80px_-40px_rgba(20,18,16,0.35)] sm:p-10"
          >
            <input type="hidden" name="form-name" value={enquiryForm.name} />
            <input
              type="hidden"
              name="subject"
              value={`New project enquiry: ${service?.name ?? 'General'}`}
            />
            <p hidden>
              <label>
                Leave this empty
                <input name="bot-field" tabIndex={-1} autoComplete="off" />
              </label>
            </p>
            <fieldset
              disabled={submission.status === 'pending'}
              className="grid gap-7 sm:grid-cols-2"
            >
              <legend className="sr-only">Your project enquiry</legend>
              <div>
                <label htmlFor="enquiry-name" className="form-label">
                  Your name
                </label>
                <input
                  id="enquiry-name"
                  name="name"
                  autoComplete="name"
                  required
                  maxLength={100}
                  placeholder="Jordan Lee"
                  className="form-input"
                />
              </div>
              <div>
                <label htmlFor="enquiry-email" className="form-label">
                  Work email
                </label>
                <input
                  id="enquiry-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  maxLength={254}
                  placeholder="jordan@company.com"
                  className="form-input"
                />
              </div>
              <div>
                <label htmlFor="enquiry-company" className="form-label">
                  Company
                </label>
                <input
                  id="enquiry-company"
                  name="company"
                  autoComplete="organization"
                  maxLength={120}
                  placeholder="Company name"
                  className="form-input"
                />
              </div>
              <div>
                <label htmlFor="enquiry-budget" className="form-label">
                  Monthly budget
                </label>
                <select
                  id="enquiry-budget"
                  name="budget"
                  defaultValue=""
                  required
                  className="form-input"
                >
                  <option value="" disabled>
                    Select a range
                  </option>
                  {budgets.map((budget) => (
                    <option key={budget}>{budget}</option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2">
                <p className="form-label" id="enquiry-service-label">
                  What do you need help with?
                </p>
                <input
                  type="hidden"
                  name="service"
                  value={service?.name ?? 'Not sure yet'}
                />
                <div
                  role="radiogroup"
                  aria-labelledby="enquiry-service-label"
                  className="mt-3 flex flex-wrap gap-2"
                >
                  {[
                    ...services.map((s) => ({ id: s.id, name: s.name })),
                    { id: 'unsure', name: 'Not sure yet' },
                  ].map((item) => {
                    const active =
                      item.id === serviceId ||
                      (item.id === 'unsure' && !service)
                    return (
                      <button
                        key={item.id}
                        type="button"
                        role="radio"
                        aria-checked={active}
                        onClick={() => onServiceChange(item.id)}
                        className={`rounded-full border-2 px-4 py-2 text-sm font-semibold transition-colors ${
                          active
                            ? 'border-ink bg-ink text-paper'
                            : 'border-ink/15 hover:border-ink'
                        }`}
                      >
                        {item.name}
                      </button>
                    )
                  })}
                </div>
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="enquiry-message" className="form-label">
                  Tell us about your goals
                </label>
                <textarea
                  id="enquiry-message"
                  name="message"
                  required
                  minLength={10}
                  maxLength={2000}
                  rows={4}
                  placeholder="Where are you today, and where do you want to be in 12 months?"
                  className="form-input resize-none"
                />
              </div>
              <div className="flex flex-wrap items-center gap-5 sm:col-span-2">
                <button
                  type="submit"
                  aria-describedby="contact-note"
                  className="action"
                >
                  {submission.status === 'pending'
                    ? 'Sending…'
                    : 'Send enquiry'}
                  <span aria-hidden>→</span>
                </button>
                <p role="status" className="sr-only">
                  {submission.status === 'pending'
                    ? 'Sending your enquiry…'
                    : ''}
                </p>
                {submission.status === 'error' && (
                  <p
                    role="alert"
                    className="text-sm font-semibold text-ember-deep"
                  >
                    We couldn’t send your enquiry. Your details are still here —
                    please try again, or email us directly.
                  </p>
                )}
              </div>
            </fieldset>
          </form>
        )}
      </div>
    </section>
  )
}
