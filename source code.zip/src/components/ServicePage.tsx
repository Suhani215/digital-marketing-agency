import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import services, { type Service } from '../data/services'
import { EnquiryForm } from './EnquiryForm'
import { SiteFooter, SiteHeader } from './SiteChrome'

export function ServicePage({ service }: { service: Service }) {
  const [serviceId, setServiceId] = useState(service.id)
  const others = services.filter((item) => item.id !== service.id).slice(0, 3)

  return (
    <>
      <SiteHeader />
      <main>
        <section className="mx-auto max-w-7xl px-5 pb-20 pt-14 sm:px-8">
          <Link to="/" hash="services" className="action-ghost text-sm">
            ← All services
          </Link>
          <div className="mt-12 grid gap-14 lg:grid-cols-[1.3fr_1fr]">
            <div>
              <p className="eyebrow rise mb-6 text-ember">Service</p>
              <h1 className="display rise text-[clamp(3.5rem,8vw,7.5rem)]">
                {service.name}
              </h1>
              <p className="rise mt-8 max-w-2xl text-xl leading-relaxed text-ink-soft">
                {service.description}
              </p>
              <a href="#contact" className="action mt-10">
                Talk to us about {service.name.toLowerCase()}{' '}
                <span aria-hidden>→</span>
              </a>
            </div>
            <aside className="self-start rounded-[2rem] bg-ink p-9 text-paper">
              <p className="eyebrow mb-6 text-paper/50">What’s included</p>
              <ul className="space-y-4">
                {service.deliverables.map((item) => (
                  <li key={item} className="flex gap-3 text-lg">
                    <span aria-hidden className="text-ember">
                      ✦
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
              <p className="mt-10 border-t border-paper/15 pt-6 text-paper/70">
                <span className="font-semibold text-paper">The outcome: </span>
                {service.outcome}
              </p>
            </aside>
          </div>
        </section>

        <section className="border-t border-ink/10">
          <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
            <p className="eyebrow mb-8 text-ink-soft">Pairs well with</p>
            <div className="grid gap-4 md:grid-cols-3">
              {others.map((item) => (
                <Link
                  key={item.id}
                  to="/services/$serviceId"
                  params={{ serviceId: item.id }}
                  className="group rounded-2xl border border-ink/15 p-7 transition-colors hover:border-ink hover:bg-ink hover:text-paper"
                >
                  <h2 className="display text-3xl">{item.name}</h2>
                  <p className="mt-3 text-sm text-ink-soft group-hover:text-paper/70">
                    {item.summary}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <EnquiryForm serviceId={serviceId} onServiceChange={setServiceId} />
      </main>
      <SiteFooter />
    </>
  )
}
