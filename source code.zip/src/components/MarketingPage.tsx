import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import services from '../data/services'
import caseStudies from '../data/caseStudies'
import { img, site } from '../data/site'
import { EnquiryForm } from './EnquiryForm'
import { SiteFooter, SiteHeader } from './SiteChrome'

export function MarketingPage() {
  const [serviceId, setServiceId] = useState('unsure')
  const [openFaq, setOpenFaq] = useState(0)

  return (
    <>
      <SiteHeader />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="mx-auto grid max-w-7xl items-end gap-12 px-5 pb-20 pt-16 sm:px-8 lg:grid-cols-[1.25fr_1fr] lg:pt-24">
            <div>
              <p className="eyebrow rise mb-8 flex items-center gap-3 text-ink-soft">
                <span className="h-2 w-2 animate-pulse rounded-full bg-ember" />
                {site.tagline} · Now booking Q1
              </p>
              <h1
                className="display rise text-[clamp(3.6rem,9vw,8.5rem)]"
                style={{ animationDelay: '80ms' }}
              >
                Marketing that
                <br />
                <em className="text-ember">earns</em> its keep.
              </h1>
              <p
                className="rise mt-8 max-w-xl text-lg leading-relaxed text-ink-soft sm:text-xl"
                style={{ animationDelay: '180ms' }}
              >
                {site.name} is a strategy-led digital marketing agency. We
                combine brand, performance media, SEO, and content to turn
                attention into revenue — and prove it.
              </p>
              <div
                className="rise mt-10 flex flex-wrap items-center gap-6"
                style={{ animationDelay: '280ms' }}
              >
                <a href="#contact" className="action">
                  Book a free growth call <span aria-hidden>→</span>
                </a>
                <a href="#work" className="action-ghost">
                  See our results
                </a>
              </div>
            </div>
            <div className="rise relative" style={{ animationDelay: '220ms' }}>
              <img
                src={img('hero.png', 900)}
                alt="An orange glass prism casting streaks of light across cream paper"
                width={900}
                height={672}
                className="aspect-[4/5] w-full rounded-[2rem] object-cover lg:rotate-2"
              />
              <div className="absolute -bottom-6 -left-4 rounded-2xl bg-ink px-6 py-5 text-paper shadow-xl sm:-left-10">
                <p className="display text-5xl text-ember">3.4×</p>
                <p className="mt-1 text-xs font-semibold uppercase tracking-widest text-paper/60">
                  Avg. return on ad spend
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Client marquee */}
        <section
          aria-label="Selected clients"
          className="border-y border-ink/10 py-7"
        >
          <div className="flex overflow-hidden">
            <ul className="marquee flex shrink-0 gap-16 pr-16">
              {[...site.clients, ...site.clients].map((client, i) => (
                <li
                  key={i}
                  aria-hidden={i >= site.clients.length}
                  className="display whitespace-nowrap text-3xl text-ink/45"
                >
                  {client}
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Services */}
        <section id="services" className="scroll-mt-20">
          <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
            <div className="mb-14 flex flex-wrap items-end justify-between gap-6">
              <div>
                <p className="eyebrow mb-5 text-ember">What we do</p>
                <h2 className="display max-w-2xl text-6xl sm:text-7xl">
                  Six disciplines. <em>One growth plan.</em>
                </h2>
              </div>
              <p className="max-w-sm text-ink-soft">
                Pick a single channel or bring us the whole funnel. Every
                engagement starts with strategy and ends with numbers.
              </p>
            </div>
            <div className="grid border-l border-t border-ink/15 sm:grid-cols-2 lg:grid-cols-3">
              {services.map((service, index) => (
                <Link
                  key={service.id}
                  to="/services/$serviceId"
                  params={{ serviceId: service.id }}
                  className="group relative flex min-h-72 flex-col border-b border-r border-ink/15 p-8 transition-colors duration-300 hover:bg-ink hover:text-paper"
                >
                  <span className="text-sm font-bold text-ember">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <h3 className="display mt-6 text-4xl">{service.name}</h3>
                  <p className="mt-4 text-ink-soft transition-colors group-hover:text-paper/70">
                    {service.summary}
                  </p>
                  <span className="mt-auto inline-flex items-center gap-2 pt-8 text-sm font-semibold">
                    Explore
                    <span
                      aria-hidden
                      className="transition-transform duration-300 group-hover:translate-x-1.5"
                    >
                      →
                    </span>
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="bg-ink text-paper">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 sm:px-8 md:grid-cols-3">
            {site.stats.map((stat) => (
              <div key={stat.label} className="border-t border-paper/20 pt-6">
                <p className="display text-7xl text-ember sm:text-8xl">
                  {stat.value}
                </p>
                <p className="mt-3 max-w-[16rem] text-paper/70">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Case studies */}
        <section id="work" className="scroll-mt-20">
          <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
            <p className="eyebrow mb-5 text-ember">Selected work</p>
            <h2 className="display mb-16 max-w-3xl text-6xl sm:text-7xl">
              Results we’re <em>proud</em> to put our name on.
            </h2>
            <div className="space-y-24">
              {caseStudies.map((study, index) => (
                <article
                  key={study.client}
                  className={`grid items-center gap-10 md:grid-cols-2 ${index % 2 === 1 ? 'md:[&>figure]:order-2' : ''}`}
                >
                  <figure className="group overflow-hidden rounded-[2rem]">
                    <img
                      src={img(study.image, 900)}
                      alt={study.imageAlt}
                      loading="lazy"
                      width={900}
                      height={491}
                      className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </figure>
                  <div>
                    <p className="eyebrow text-ink-soft">
                      {study.client} — {study.industry}
                    </p>
                    <h3 className="display mt-5 text-4xl sm:text-5xl">
                      {study.headline}
                    </h3>
                    <dl className="mt-8 grid grid-cols-2 gap-6">
                      {study.metrics.map((metric) => (
                        <div
                          key={metric.label}
                          className="border-l-2 border-ember pl-5"
                        >
                          <dt className="text-sm text-ink-soft">
                            {metric.label}
                          </dt>
                          <dd className="display text-5xl">{metric.value}</dd>
                        </div>
                      ))}
                    </dl>
                    <ul className="mt-8 flex flex-wrap gap-2">
                      {study.services.map((name) => (
                        <li
                          key={name}
                          className="rounded-full border border-ink/20 px-3 py-1 text-xs font-semibold"
                        >
                          {name}
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Process */}
        <section id="process" className="scroll-mt-20 border-t border-ink/10">
          <div className="mx-auto grid max-w-7xl gap-14 px-5 py-24 sm:px-8 lg:grid-cols-[1fr_1.4fr]">
            <div>
              <p className="eyebrow mb-5 text-ember">How we work</p>
              <h2 className="display text-6xl sm:text-7xl">
                A simple process, <em>run with rigor.</em>
              </h2>
              <img
                src={img('studio.png', 800)}
                alt="The Northlight team collaborating around a table of mood boards"
                loading="lazy"
                width={800}
                height={436}
                className="mt-10 aspect-[16/10] w-full rounded-[2rem] object-cover"
              />
            </div>
            <ol className="divide-y divide-ink/15 border-y border-ink/15">
              {site.process.map((item) => (
                <li
                  key={item.step}
                  className="group grid grid-cols-[4rem_1fr] gap-4 py-9"
                >
                  <span className="display text-3xl text-ember">
                    {item.step}
                  </span>
                  <div>
                    <h3 className="display text-4xl transition-transform duration-300 group-hover:translate-x-2">
                      {item.title}
                    </h3>
                    <p className="mt-3 max-w-lg text-ink-soft">
                      {item.description}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Testimonials */}
        <section className="bg-ember text-ink">
          <div className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
            <p className="eyebrow mb-12">Kind words</p>
            <div className="grid gap-10 md:grid-cols-3">
              {site.testimonials.map((t) => (
                <figure key={t.name} className="flex flex-col">
                  <blockquote className="display text-3xl leading-tight">
                    “{t.quote}”
                  </blockquote>
                  <figcaption className="mt-auto pt-8 text-sm">
                    <span className="font-bold">{t.name}</span>
                    <br />
                    <span className="text-ink/70">{t.role}</span>
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="scroll-mt-20">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 py-24 sm:px-8 lg:grid-cols-[1fr_1.4fr]">
            <div>
              <p className="eyebrow mb-5 text-ember">FAQ</p>
              <h2 className="display text-6xl sm:text-7xl">
                Good <em>questions.</em>
              </h2>
            </div>
            <div className="border-t border-ink/15">
              {site.faqs.map((faq, index) => {
                const open = openFaq === index
                return (
                  <div key={faq.question} className="border-b border-ink/15">
                    <h3>
                      <button
                        type="button"
                        aria-expanded={open}
                        aria-controls={`faq-${index}`}
                        onClick={() => setOpenFaq(open ? -1 : index)}
                        className="flex w-full items-center justify-between gap-6 py-7 text-left text-xl font-semibold"
                      >
                        {faq.question}
                        <span
                          aria-hidden
                          className={`grid h-9 w-9 shrink-0 place-items-center rounded-full border-2 border-ink text-lg transition-transform duration-300 ${open ? 'rotate-45 bg-ink text-paper' : ''}`}
                        >
                          +
                        </span>
                      </button>
                    </h3>
                    <div
                      id={`faq-${index}`}
                      hidden={!open}
                      className="max-w-xl pb-7 text-ink-soft"
                    >
                      {faq.answer}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </section>

        <EnquiryForm serviceId={serviceId} onServiceChange={setServiceId} />
      </main>
      <SiteFooter />
    </>
  )
}
