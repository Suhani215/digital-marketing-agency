import { Link } from '@tanstack/react-router'
import { site } from '../data/site'

export function Logo() {
  return (
    <Link to="/" className="group inline-flex items-center gap-2.5">
      <span
        aria-hidden
        className="relative h-7 w-7 rounded-full bg-ink transition-transform duration-500 group-hover:rotate-180"
      >
        <span className="absolute right-0 top-0 h-3.5 w-3.5 rounded-full bg-ember" />
      </span>
      <span className="text-xl font-extrabold tracking-tight">{site.name}</span>
    </Link>
  )
}

const nav = [
  { href: '/#services', label: 'Services' },
  { href: '/#work', label: 'Work' },
  { href: '/#process', label: 'Process' },
  { href: '/#faq', label: 'FAQ' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-ink/10 bg-paper/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 py-4 sm:px-8">
        <Logo />
        <nav aria-label="Main" className="hidden items-center gap-8 md:flex">
          {nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm font-semibold text-ink-soft transition-colors hover:text-ink"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <a href="#contact" className="action !px-5 !py-2.5 text-sm">
          Start a project
        </a>
      </div>
    </header>
  )
}

export function SiteFooter() {
  return (
    <footer className="bg-ink text-paper">
      <div className="mx-auto max-w-7xl px-5 pb-10 pt-20 sm:px-8">
        <p className="display text-[clamp(3.5rem,13vw,11rem)] text-paper/95">
          Let’s make
          <br />
          <em className="text-ember">some noise.</em>
        </p>
        <div className="mt-16 grid gap-10 border-t border-paper/15 pt-10 text-sm sm:grid-cols-3">
          <div>
            <p className="eyebrow mb-3 text-paper/50">Say hello</p>
            <a
              href={`mailto:${site.email}`}
              className="text-lg font-semibold hover:text-ember"
            >
              {site.email}
            </a>
          </div>
          <div>
            <p className="eyebrow mb-3 text-paper/50">Studio</p>
            <p className="text-lg">{site.location}</p>
          </div>
          <div className="sm:text-right">
            <p className="eyebrow mb-3 text-paper/50">Elsewhere</p>
            <p className="space-x-5 text-lg">
              <a href="#" className="hover:text-ember">
                LinkedIn
              </a>
              <a href="#" className="hover:text-ember">
                Instagram
              </a>
            </p>
          </div>
        </div>
        <p className="mt-14 text-xs text-paper/40">
          © {new Date().getFullYear()} {site.name}. Client names and results
          shown are illustrative.
        </p>
      </div>
    </footer>
  )
}
