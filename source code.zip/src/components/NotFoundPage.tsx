import { Link } from '@tanstack/react-router'

export function NotFoundPage() {
  return (
    <main className="mx-auto flex min-h-[80vh] max-w-2xl flex-col justify-center p-8">
      <p className="eyebrow mb-6 text-ember">404</p>
      <h1 className="display mb-6 text-7xl">
        This page went <em>off-strategy.</em>
      </h1>
      <p className="mb-10 text-lg text-ink-soft">
        We couldn’t find what you were looking for.
      </p>
      <Link to="/" className="action self-start">
        Back to home
      </Link>
    </main>
  )
}
