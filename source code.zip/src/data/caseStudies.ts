export interface CaseStudy {
  client: string
  industry: string
  headline: string
  image: string
  imageAlt: string
  metrics: Array<{ value: string; label: string }>
  services: Array<string>
}

const caseStudies: Array<CaseStudy> = [
  {
    client: 'Kopi & Co.',
    industry: 'Specialty coffee · DTC',
    headline: 'Turning a local roastery into a national subscription brand.',
    image: 'case-roast.png',
    imageAlt: 'Coffee bag and ceramic cup on a stone counter in morning light',
    metrics: [
      { value: '+212%', label: 'Subscription revenue' },
      { value: '4.1×', label: 'Blended ROAS' },
    ],
    services: ['Performance Media', 'Email & Lifecycle'],
  },
  {
    client: 'Ledgerly',
    industry: 'Fintech · B2B SaaS',
    headline: 'Doubling qualified demos while cutting cost per lead in half.',
    image: 'case-fintech.png',
    imageAlt: 'Hand holding a smartphone showing a colorful app interface',
    metrics: [
      { value: '2.1×', label: 'Qualified demos' },
      { value: '−48%', label: 'Cost per lead' },
    ],
    services: ['Performance Media', 'Web & Conversion'],
  },
  {
    client: 'Alpenrise',
    industry: 'Outdoor apparel · E-commerce',
    headline: 'Tripling organic traffic with content that climbs the rankings.',
    image: 'case-outdoor.png',
    imageAlt: 'Hiker in an orange jacket on a misty mountain ridge at sunrise',
    metrics: [
      { value: '3.2×', label: 'Organic sessions' },
      { value: '+68%', label: 'Organic revenue' },
    ],
    services: ['SEO & Organic Growth', 'Social & Content'],
  },
]

export default caseStudies
