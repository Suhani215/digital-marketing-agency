export interface Service {
  id: string
  name: string
  summary: string
  description: string
  deliverables: Array<string>
  outcome: string
}

const services: Array<Service> = [
  {
    id: 'performance-media',
    name: 'Performance Media',
    summary: 'Paid search, social, and programmatic built around profit.',
    description:
      'We plan, launch, and optimize paid campaigns across Google, Meta, TikTok, LinkedIn, and programmatic networks. Every campaign is tied to revenue or pipeline, with creative testing and budget pacing handled weekly.',
    deliverables: [
      'Account audit & restructure',
      'Creative testing roadmap',
      'Conversion tracking & attribution',
      'Weekly optimization & pacing',
    ],
    outcome: 'Lower acquisition costs and spend you can defend.',
  },
  {
    id: 'seo',
    name: 'SEO & Organic Growth',
    summary: 'Technical SEO and content that compounds month after month.',
    description:
      'From site architecture and Core Web Vitals to topical content strategy and digital PR, we build organic visibility that keeps paying off long after a campaign ends.',
    deliverables: [
      'Technical SEO audit',
      'Keyword & topic mapping',
      'On-page optimization',
      'Link earning & digital PR',
    ],
    outcome: 'Durable traffic from people searching for what you sell.',
  },
  {
    id: 'social-content',
    name: 'Social & Content',
    summary: 'Thumb-stopping content and community that builds a brand.',
    description:
      'Platform-native content for Instagram, TikTok, LinkedIn, and YouTube — plus the strategy, calendar, and community management to keep it consistent and on-brand.',
    deliverables: [
      'Content strategy & pillars',
      'Short-form video production',
      'Monthly content calendar',
      'Community management',
    ],
    outcome: 'An audience that recognizes you — and remembers you.',
  },
  {
    id: 'brand-strategy',
    name: 'Brand Strategy',
    summary: 'Positioning and messaging that makes every channel work harder.',
    description:
      'We clarify who you serve, why you win, and how you sound. The result is a positioning and messaging system your whole team — and every campaign — can rely on.',
    deliverables: [
      'Audience research & interviews',
      'Positioning & value proposition',
      'Messaging framework',
      'Visual direction',
    ],
    outcome: 'Sharper positioning that lifts conversion everywhere.',
  },
  {
    id: 'web-cro',
    name: 'Web & Conversion',
    summary: 'Landing pages and experiments that turn clicks into customers.',
    description:
      'Fast, focused landing pages and a disciplined A/B testing program. We find friction in your funnel and remove it, one validated experiment at a time.',
    deliverables: [
      'Funnel & UX audit',
      'Landing page design & build',
      'A/B testing program',
      'Analytics & heatmaps',
    ],
    outcome: 'More revenue from the traffic you already have.',
  },
  {
    id: 'email-lifecycle',
    name: 'Email & Lifecycle',
    summary: 'Automations that nurture, convert, and retain.',
    description:
      'Welcome series, abandoned-cart flows, win-back campaigns, and newsletters people actually open. We design the lifecycle so every customer gets the right message at the right moment.',
    deliverables: [
      'Lifecycle journey mapping',
      'Automated flows',
      'Campaign design & copy',
      'Segmentation & deliverability',
    ],
    outcome: 'Higher lifetime value from every customer you win.',
  },
]

export default services

export function findService(id: string) {
  return services.find((service) => service.id === id)
}
