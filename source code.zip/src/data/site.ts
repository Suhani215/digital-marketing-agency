export const site = {
  name: 'Northlight',
  tagline: 'Digital marketing studio',
  description:
    'Northlight is a digital marketing agency that blends brand strategy, performance media, SEO, and content to turn attention into measurable growth.',
  email: 'hello@northlight.studio',
  location: 'Remote-first · Lisbon & New York',
  stats: [
    {
      value: '3.4×',
      label: 'Average return on ad spend across retained clients',
    },
    { value: '120+', label: 'Brands launched, scaled, or relaunched' },
    { value: '92%', label: 'Client retention after the first year' },
  ],
  clients: [
    'Fieldhouse',
    'Saltgrain',
    'Kopi & Co.',
    'Ledgerly',
    'Alpenrise',
    'Moonmilk',
    'Parcel Nine',
    'Verdant',
  ],
  process: [
    {
      step: '01',
      title: 'Listen',
      description:
        'A two-week deep dive into your audience, analytics, and competitors. We find the leaks before we spend a dollar.',
    },
    {
      step: '02',
      title: 'Plan',
      description:
        'A channel plan with clear targets, budgets, and a 90-day roadmap — written in plain language, not jargon.',
    },
    {
      step: '03',
      title: 'Launch',
      description:
        'Campaigns, content, and landing pages go live in sprints. You see the work weekly, not quarterly.',
    },
    {
      step: '04',
      title: 'Compound',
      description:
        'We test relentlessly, cut what doesn’t work, and reinvest in what does. Growth that builds on itself.',
    },
  ],
  testimonials: [
    {
      quote:
        'Northlight rebuilt our paid funnel in six weeks. We doubled qualified demos and finally know which channels actually work.',
      name: 'Priya Raman',
      role: 'VP Growth, Ledgerly',
    },
    {
      quote:
        'They feel like part of our team. Thoughtful creative, honest reporting, and zero fluff in the monthly reviews.',
      name: 'Tomás Ferreira',
      role: 'Founder, Kopi & Co.',
    },
    {
      quote:
        'Our organic traffic tripled in a year. More importantly, it’s the right traffic — people who buy.',
      name: 'Hannah Lindqvist',
      role: 'Head of E-commerce, Alpenrise',
    },
  ],
  faqs: [
    {
      question: 'What size of company do you work with?',
      answer:
        'Mostly founder-led and scaling brands with $1M–$50M in revenue. Big enough to invest in growth, small enough that our work moves the needle.',
    },
    {
      question: 'Is there a minimum engagement?',
      answer:
        'Retainers start at three months so there’s time to test and learn. Audits and one-off strategy sprints are available on their own.',
    },
    {
      question: 'How do you report on results?',
      answer:
        'You get a live dashboard plus a short weekly note and a monthly review call. We report on revenue and pipeline, not vanity metrics.',
    },
    {
      question: 'Do you work with our in-house team?',
      answer:
        'Absolutely. Many clients keep in-house marketers and use us for specialist channels, strategy, or extra creative capacity.',
    },
  ],
}

export const enquiryForm = {
  name: 'project-enquiry',
  endpoint: '/__forms.html',
}

export const budgets = [
  'Under $5k / month',
  '$5k–$15k / month',
  '$15k–$50k / month',
  '$50k+ / month',
  'Not sure yet',
]

/** Builds a Netlify Image CDN URL for a file in public/img. */
export const img = (file: string, width: number) =>
  `/.netlify/images?url=/img/${file}&w=${width}&fm=webp`
