import { describe, expect, it } from 'vitest'
import services, { findService } from './services'

describe('findService', () => {
  it('finds services by their exact slug', () => {
    expect(findService('seo')?.name).toBe('SEO & Organic Growth')
  })

  it('returns undefined for unknown or noncanonical slugs', () => {
    expect(findService('SEO')).toBeUndefined()
    expect(findService('missing')).toBeUndefined()
  })

  it('uses unique slugs', () => {
    const ids = services.map((service) => service.id)
    expect(new Set(ids).size).toBe(ids.length)
  })
})
