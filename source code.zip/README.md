# Northlight — Digital Marketing Agency Website

The marketing website for **Northlight**, a strategy-led digital marketing agency. It presents the agency's services, results, and process, and captures new-business enquiries.

## What's on the site

- **Homepage** — hero, client marquee, six service disciplines, headline stats, case studies, process, testimonials, FAQ, and a project enquiry form.
- **Service pages** (`/services/<slug>`) — one page per service with deliverables, outcomes, related services, and an enquiry form preselected for that service.
- **Project enquiry form** — collects name, email, company, budget, service of interest, and goals. Submissions are stored by Netlify Forms (visible in the Netlify dashboard under Forms).

## Tech

- [TanStack Start](https://tanstack.com/start) + React 19, file-based routing
- Tailwind CSS v4 (theme tokens in `src/styles.css`)
- Netlify Forms for enquiries, Netlify Image CDN for optimized imagery
- Fonts: Instrument Serif (display) and Manrope (body) via Google Fonts

## Run locally

```bash
pnpm install
netlify dev    # or: pnpm dev
```

Form submissions are only processed on a deployed Netlify site (or via `netlify dev`); a plain Vite preview shows an error state instead of a false success.

## Editing content

All copy lives in `src/data/`:

- `site.ts` — brand name, tagline, contact email, stats, client names, process, testimonials, FAQ, budget ranges
- `services.ts` — the six services and their detail-page copy
- `caseStudies.ts` — case study cards and metrics

Images are in `public/img/`. Client names, testimonials, and results are illustrative placeholders — replace them with real ones before launch.

## Publish to GitHub

1. Download this project's source (from the Netlify dashboard, or by cloning the Netlify-hosted Git repository) and unzip it.
2. Create a new, empty repository on GitHub (no README, `.gitignore`, or license, so the first push doesn't conflict).
3. From the project folder, run:

   ```bash
   git init
   git add .
   git commit -m "Initial commit: Northlight agency website"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```

4. Optional: in Netlify, open **Project configuration → Build & deploy → Continuous deployment** and link the new GitHub repository so every push deploys automatically. The build settings are already defined in `netlify.toml`.

`node_modules`, build output (`dist`), local Netlify state (`.netlify`), and `.env` files are excluded by `.gitignore`. Never commit secrets.
